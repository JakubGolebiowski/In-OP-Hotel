
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.2/css/bulma.css"> -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="font-awesome-4_7_0/css/font-awesome.min.css">

  <link rel="stylesheet" href="style.css">
  <title>InOP</title>
</head>
<body>
  <div class="text-center containerFluidIndex">

    <div class="border border-success rounded pt-5 pb-5">

      <div class="row justify-content-center">
        <div class="col-10">
          <h1 class="title" ><b>Numer Twojego miejsca parkingowego: </b></h1><br>
          <h1 class="title" ><b><?php
session_start();

if((isset($_SESSION['start']))&&($_SESSION['start']==true))
{
	echo $_SESSION['numer'];
}

?></b></h1>
          <br>
        </div>
      </div>
<br>
    </div>

    <div class="divButtonWybierzWersje text-center">
      <a href="oNasRegulamin.html">
        <button class="btn btn-success batonWybierzWersje" type="button">Wróć na stronę główną</button>
      </a>
    </div>
  </div>

</body>
</html>
