<?php
session_start();

if((isset($_SESSION['start']))&&($_SESSION['start']==true))
{


$osoby=$_POST['ileosob'];

$_SESSION['dod']=$_POST['dzienod'];
$_SESSION['mod']=$_POST['miesiacod'];
$_SESSION['rod']=$_POST['rokod'];
$_SESSION['ddo']=$_POST['dziendo'];
$_SESSION['mdo']=$_POST['miesiacdo'];
$_SESSION['rdo']=$_POST['rokdo'];

$od=mktime(0,0,0,$_SESSION['mod'], $_SESSION['dod'], $_SESSION['rod']);
$do=mktime(0,0,0,$_SESSION['mdo'], $_SESSION['ddo'], $_SESSION['rdo']);
$_SESSION['dlugosc']=(($do-$od)/86400)+1;
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.2/css/bulma.css">
  <title>InOP</title>
</head>
<body>
  <div class="container"></div>

    <!-- BOX -->

    <div class="block">
      <div class="columns">
        <div class="column is-2">
        </div>
        <div class="column is-8">
          <div class="block" style="margin-top: 10%;">
            <div class="box has-text-centered" style="height:600px;  border-radius: 5px; box-shadow: 0 2px 3px rgba(0, 0, 0, 0.96), 0 0 0 1px rgb(0, 0, 0);">
                <div class="block">
                    <div class="box has-text-centered" style="height:560px;  border-radius: 5px; box-shadow: 0 2px 3px rgba(0, 0, 0, 0.96), 0 0 0 1px rgb(0, 0, 0);">
                        <h1 class="title" style="font-size:2em;"><b>Dostępne Pokoje</b></h1>
                        <div style="height:25px;"></div>
<!-- BEGIN -->
<?php
require_once "connect.php";

$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);

if ($polaczenie->connect_errno!=0)
{
	echo "Error: ".$polaczenie->connect_errno;
}
else
{
	
$z = $polaczenie->query("SELECT * FROM pokoje WHERE ile_osob='$osoby'");


while ($r = $z->fetch_assoc()) {
$flaga=0;
	
	$x = $polaczenie->query("SELECT * FROM rezerwacje WHERE nr_pokoju = '$r[nr_pokoju]'");
	while($a= $x->fetch_assoc()){
		$bod=mktime(0,0,0, $a["miesod"], $a["dzienod"], $a["rokod"]);
		$bdo=mktime(0,0,0, $a["miesdo"], $a["dziendo"], $a["rokdo"]);
	if(($od<=$bod&&$od<=$bdo&&$do>=$bod&&$do<=$bdo)||($od>=$bod&&$od<=$bdo&&$do>=$bod&&$do<=$bdo)||($od>=$bod&&$od<=$bdo&&$do>=$bod&&$do>=$bdo)||($od<=$bod&&$od<=$bdo&&$do>=$bod&&$do>=$bdo)||($od==$bod&&$do==$bdo)||($od!=$bod&&$do==$bdo)||($od==$bod&&$do!=$bdo))
	{$flaga=1;}
	else
	{
		

	
	
	}
}
if($flaga==0)
{		echo '        <form method="POST" action="infoOPokoju.php">
		<div class="row justify-content-center mt-5 mb-5 text form-check">
                <div class="form-check">
                    <label class="form-check-label">
	<input type="radio" class="form-check-input" name="pokoj" value="'.$r["nr_pokoju"].'"><span class="span1Input">'.$osoby.'-osobowy</span> <span class="span1Input">'.$r["opis"].'</span> <span class="span1Input">'.$r["cena"].'</span>
              </label>
                </div>
            </div>';}


}
echo '			        <div class="divButtonWybierzWersje text-center">
<input type="submit" value="Przejdź dalej"></div>
			</form>';

$z->free();
$polaczenie->close();	
}

?>

<!-- END -->
 

                    </div>
                  </div>
            </div>
          </div>
        </div>
        <div class="column is-2">

        </div>
      </div>
    </div>

  </div><!-- /. container -->


</body>
</html>