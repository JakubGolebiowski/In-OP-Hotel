<?php
session_start();
if((isset($_SESSION['start']))&&($_SESSION['start']==true))
{

}	

?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.2/css/bulma.css"> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="font-awesome-4_7_0/css/font-awesome.min.css">

    <link rel="stylesheet" href="style.css">
    <title>InOP</title>
</head>

<body>
    <div class="text-center containerFluidIndex">
        <div class="border border-success rounded pt-5 pb-5">
            <div class="row justify-content-center">
                <div class="col-4">
                    <h1>Wprowadź swoje dane osobowe</h1>
                </div>
            </div>

            <div class="row justify-content-center mt-5 mb-5 text form-check">


                <form action="daneRezerwacji.php" method="POST">
                    <div class="daneOsoboweWprowadz">
                        <label class="label">Imię</label><br>
                        <input id="imie" name="imie" type="text" class="input" placeholder="Imię">
                    </div>

                    <div class="daneOsoboweWprowadz">
                        <label class="label">Nazwisko</label><br>
                        <input id="nazwisko" name="nazwisko" type="text" class="input" placeholder="Nazwisko">
                    </div>

                    <div class="daneOsoboweWprowadz">
                        <label class="label">Adres e-mail</label><br>
                        <input id="mail" name="mail" type="text" type="email" class="input" placeholder="Adress email">
                    </div>

                    <div class="daneOsoboweWprowadz">
                        <label class="label">Data urodzenia</label>
                    </div>
                    <div class="columns is-mobile is-centered">
                        <div class="daneOsoboweWprowadz ">
                            <div class="control">
                                <input id="data" name="data" type="text" class="input" placeholder="rrrr-mm-dd">
                            </div>
                        </div>
                    </div><br>
                    <div class="row justify-content-center">
                        <div class="col-4">
                            <h1>Do zapłaty: <?php echo $_SESSION['koszt']; ?> zł</h1>
                        </div>
                    </div><br>
                    <div class="row justify-content-center">
                        <div class="col-4">
                            <h1>Wybierz rodzaj płatności</h1>
                        </div>
                    </div><br>
                    <div class="radio daneOsoboweWprowadz">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="platnosc" value="gotowka"><span class="span1Input">Gotówka</span>
                        </label>
                    </div><br>
                    <div class="radio daneOsoboweWprowadz">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="platnosc" value="przelew"><span class="span1Input">Przelew</span>
                        </label>
                    </div>

            </div>

            <div class="divButtonWybierzWersje text-center">
                    <input class="bg-success batonWybierzWersje" type="submit" value="Przejdź dalej" />

            </div>
			                </form>
        </div>
    </div>




</body>

</html>