<?php
session_start();

if((isset($_SESSION['zalogowany']))&&($_SESSION['zalogowany']==true))
{

}
else
{
	$_SESSION['id_prac']=$_POST['nrPracownika'];	
	
	require_once "connect.php";

$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);

if ($polaczenie->connect_errno!=0)
{
	echo "Error: ".$polaczenie->connect_errno;
}
else
{

	$z = $polaczenie->query("SELECT * FROM pracownik WHERE nr_id='$_SESSION[id_prac]'");
	
	
		$ile=$z->num_rows;
		if($ile==1)
		{
			$_SESSION['zalogowany']=true;
			
			$zz=$z->fetch_assoc();			
			$_SESSION['imie']=$zz['imie'];
			$_SESSION['nazwisko']=$zz['nazwisko'];
			unset($_SESSION['blad']);
		}
		else{
			header('Location:logowaniePracownika.php');
		
		}
		
		
	$polaczenie->close();	
}
	
	
}






?>
<!DOCTYPE html>
<html lang="pl">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.2/css/bulma.css"> -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="font-awesome-4_7_0/css/font-awesome.min.css">

  <link rel="stylesheet" href="../style.css">
  <title>InOP</title>
</head>

<body>
  <div class="text-center containerFluidIndex">

    <div class="border border-success rounded pt-5 pb-5">

      <div class="row justify-content-center">
        <div class="col-sm-12 col-md-12 col-lg-10 col-xl-10 mt-5 mb-5">
          <a href="wylogowywanie.php">
            <button class="btn btn-success batonWybierzWersje float-right">Wyloguj się</button>
          </a>
        </div>
        <div class="col-10">
          <h1 class="title"><b>Witaj <?php echo $_SESSION['imie']."  ".$_SESSION['nazwisko']; ?>. Wybierz co chcesz zrobić. </b></h1>
        </div>
      </div>
      <br>
      <div class="row divButtonWybierzWersje text-center">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-4  mb-6">
          <a href="znajdzKlienta.php">
            <button class="btn btn-success batonWybierzWersje">Znajdź klienta <br> w systemie</button>
          </a>
        </div>
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-4  mb-6">
          <a href="iloscWolnychPokoi.php">
            <button class="btn btn-success batonWybierzWersje" type="button">Pokaż ilość <br> wolnych pokoi</button>
          </a>
        </div>
        
      </div>
      <div class="row divButtonWybierzWersje text-center">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-4  mb-6">
          <a href="iloscZarezerwowanychOsob.php">
            <button class="btn btn-success batonWybierzWersje">Pokaż listę <br>zarezerwowanych osób</button>
          </a>
        </div>
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-4  mb-6">
          <a href="listaObecnychGosci.php">
            <button class="btn btn-success batonWybierzWersje" type="button">Pokaż liczbę osób obecnie <br> przebywających w hotelu</button>
          </a>
        </div>
        
      </div>
    </div>


  </div>

</body>

</html>