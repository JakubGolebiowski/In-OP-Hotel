<?php


session_start();

session_unset();


?>
<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.2/css/bulma.css"> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="font-awesome-4_7_0/css/font-awesome.min.css">

    <link rel="stylesheet" href="../style.css">

    <title>InOP</title>
</head>

<body>

    <!-- BOX -->

    <div class="text-center containerFluidIndexMain">
        <h1 class="titleHotel">Zostałeś poprawnie wylogowany z systemu</h1>

        <div class="buttonTitle">
            <a href="../index.html">
                <button class="btn btn-success batonPadding" type="button">Wyjdź z aplikacji</button>
            </a>
        </div>


    </div>



    <!-- /. container -->


</body>

</html>