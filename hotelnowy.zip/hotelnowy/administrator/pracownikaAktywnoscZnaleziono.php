<?php
session_start();

if((isset($_SESSION['zalogowanyA']))&&($_SESSION['zalogowanyA']==true))
{
							require_once "connect.php";

$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);

if ($polaczenie->connect_errno!=0)
{
	echo "Error: ".$polaczenie->connect_errno;
}
else
{
$imie=$_POST['imie'];
$nazwisko=$_POST['nazwisko'];
$id=$_POST['nrID'];

	$z = $polaczenie->query("SELECT PESEL FROM Pracownik WHERE imie='$imie' AND nazwisko='$nazwisko' AND nr_id='$id'");
	 $ile=$z->num_rows;
	if($ile==1)
	{
		if((isset($_SESSION['zalogowany']))&&($_SESSION['zalogowany']==true)&&($_SESSION['id_prac']==$id))
		{
		$odp="tak";
		}
		else{
		$odp="nie";}
		
	}
	else{
			header('Location:pracownikaNieZnaleziono.html');

	}
			unset($_SESSION['blad']);

		
	$polaczenie->close();	
}
}
else{			
	header('Location:logowanieAdministratora.php');
}

?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.2/css/bulma.css"> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="font-awesome-4_7_0/css/font-awesome.min.css">

    <link rel="stylesheet" href="../style.css">
    <title>InOP</title>
</head>

<body>
    <div class="text-center containerFluidIndex">
        <div class="border border-success rounded pt-5 pb-5">
            <div class="row justify-content-center">
                <div class="col-sm-12 col-md-12 col-lg-10 col-xl-10 mt-5 mb-5">
                    <a href="wylogowywanie.php">
                        <button class="btn btn-success batonWybierzWersje float-right">Wyloguj się</button>
                    </a>
                </div>

                <div class="col-8">
                    <h1><b>Znajdź pracownika</b></h1>
                </div>
                <div class="col-10">
                    <h1>Pracownik został znaleziony</h1>
                </div>
                <div class="col-10">
                    <h1>Czy jest zalogowany: <?php echo $odp;?></h1>
                </div>
            </div>

        </div>
        <div class="divButtonWybierzWersje">
            <a href="witajAdmin.php">
                <button class="btn btn-success batonWybierzWersje" type="button">Strona główna</button>
            </a>
        </div>
    </div>




</body>

</html>