<?php
session_start();
if(isset($_SESSION['anulowanie'])&&$_SESSION['anulowanie']==true)
{
$imie=$_POST['imie'];
$nazwisko=$_POST['nazwisko'];
$_SESSION['nr']=$_POST['nrRezerwacji'];
	// unset($_SESSION['brakrez']);



require_once "connect.php";
	
	
	try 
	{
		$polaczenie = new mysqli($host, $db_user, $db_password, $db_name);
		
		if ($polaczenie->connect_errno!=0)
		{
			throw new Exception(mysqli_connect_errno()); 
		}
		else
		{
			$rezultat=$polaczenie->query("SELECT * FROM rezerwacje WHERE id_rezerwacji='$_SESSION[nr]'");
			if (!$rezultat) throw new Exception ($polaczenie->error);
			$ile=$rezultat->num_rows;
			if($ile>0)
			{
				$rez=$rezultat->fetch_assoc();
				$nrpokoju=$rez['nr_pokoju'];
				$dod=$rez['dzienod'];
				$mod=$rez['miesod'];
				$rod=$rez['rokod'];

				$ddo=$rez['dziendo'];
				$mdo=$rez['miesdo'];
				$rdo=$rez['rokdo'];
			}
			else
			{
			header("Location:wyswietlAnulujRezerwacje.php");
			$_SESSION['brakrez']=true;
			}
					
			
			$polaczenie->close();
		}	
	}
	catch (Exception $e)
	{
		echo 'Błąd serwera'.$e;
	}
	
	}
?>
<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.2/css/bulma.css"> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="font-awesome-4_7_0/css/font-awesome.min.css">

    <link rel="stylesheet" href="style.css">

    <title>InOP</title>
</head>

<body>

    <div class="containerFluidIndex">
        <div class="border border-success rounded pt-5 pb-5">

            <h1 class="text-center">Informacje o pokoju</h1>
            <!-- Jeśli tak-->
            <div class="offset-1 col-10 col-sm-10 col-md-10 col-lg-10 col-xl-10 border border-success rounded">
                <h1>Dane rezerwacji zostały znalezione pomyślnie:<br> Wynająłeś pokój: 
				<?php echo $nrpokoju;?> , w dniach <?php    echo $dod.'/'.$mod.'/'.$rod.' - '.$ddo.'/'.$mdo.'/'.$rdo; ?></h1>
            </div>

        </div>
        
        <!-- Jeśli tak-->
        <div class="divButtonWybierzWersje text-center">
            <a href="jestesPewny.php">
                <button class="btn btn-success batonWybierzWersje" type="button">Anuluj rezerwację</button>
            </a>
            <a href="oNasRegulamin.html">
                <button class="btn btn-success batonWybierzWersje" type="button">Wróć na stronę główną</button>
            </a>
        </div>
        <!--END-->
    </div>




</body>

</html>