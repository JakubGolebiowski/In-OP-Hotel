<?php
session_start();

if((isset($_SESSION['zalogowany']))&&($_SESSION['zalogowany']==true))
{}
else
{
header('logowaniePracownika.php');
}
?>
<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.2/css/bulma.css"> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="font-awesome-4_7_0/css/font-awesome.min.css">

    <link rel="stylesheet" href="../style.css">
    <title>InOP</title>
</head>

<body>
    <div class="text-center containerFluidIndex">
        <div class="border border-success rounded pt-5 pb-5">
            <div class="row justify-content-center">
                <div class="col-sm-12 col-md-12 col-lg-10 col-xl-10 mt-5 mb-5">
                    <a href="wylogowywanie.php">
                        <button class="btn btn-success batonWybierzWersje float-right">Wyloguj się</button>
                    </a>
                </div>

                <div class="col-8">
                    <h1><b>Ilość wolnych pokoi</b></h1>
                </div>
				  <div class="border border-success rounded col-10">
				<?php
require_once "connect.php";

$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);

if ($polaczenie->connect_errno!=0)
{
	echo "Error: ".$polaczenie->connect_errno;
}
else
{	
	$dzisiaj  = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
	$bod=mktime(0,0,0, $_SESSION["mod"], $_SESSION["dod"], $_SESSION["rod"]);
	$bdo=mktime(0,0,0, $_SESSION["mdo"], $_SESSION["ddo"], $_SESSION["rdo"]);
	
$z = $polaczenie->query("SELECT * FROM pokoje");
$licznik=0;
$nr=0;
while ($r = $z->fetch_assoc())
	{
		$flaga=true;
		$nr=$r['nr_pokoju'];
		$x = $polaczenie->query("SELECT * FROM rezerwacje WHERE nr_pokoju = '$r[nr_pokoju]'");
		while($a= $x->fetch_assoc())
		{
		if($dzisiaj>=$bod&&$dzisiaj<=$bdo)
			{$flaga=false; break;}
		}
		if($flaga==true)
		{
	echo ' <div class="row justify-content-center mt-5 mb-5 text form-check col-12">
                        <span class="span1Input">'.$r["ile_osob"].'-osobowy</span> <span class="span1Input">'.$r["opis"].'</span>
                        <span class="span1Input">'.$r["cena"].'</span>
                    </div>';
					$licznik=$licznik+1;
		}

	}
$z->free();
$polaczenie->close();	
}
?>


 




</div>
			              <div class="col-10">
                    <h1>Obecnie w hotelu wolnych pokoi: <?php echo $licznik; ?></h1> <br>
                </div>	

            </div>
        </div>
        <div class="divButtonWybierzWersje">
            <a href="witajPracownik.php">
                <button class="btn btn-success batonWybierzWersje" type="button">Strona główna</button>
            </a>
        </div>
    </div>

</body>

</html>