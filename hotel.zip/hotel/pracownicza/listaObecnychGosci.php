<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.2/css/bulma.css"> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="font-awesome-4_7_0/css/font-awesome.min.css">

    <link rel="stylesheet" href="../style.css">
    <title>InOP</title>
</head>

<body>
    <div class="text-center containerFluidIndex">
        <div class="border border-success rounded pt-5 pb-5">
            <div class="row justify-content-center">
                <div class="col-sm-12 col-md-12 col-lg-10 col-xl-10 mt-5 mb-5">
                    <a href="wylogowywanie.php">
                        <button class="btn btn-success batonWybierzWersje float-right">Wyloguj się</button>
                    </a>
                </div>

                <div class="col-8">
                    <h1><b>Lista klientów obecnie przebywających w hotelu</b></h1>
                </div>
<?php

require_once "connect.php";

$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);

if ($polaczenie->connect_errno!=0)
{
	echo "Error: ".$polaczenie->connect_errno;
}
else
{	
	$dzisiaj  = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
	
$z = $polaczenie->query("SELECT * FROM rezerwacje");

while ($r = $z->fetch_assoc())
{
		$bod=mktime(0,0,0, $r["miesod"], $r["dzienod"], $r["rokod"]);
		$bdo=mktime(0,0,0, $r["miesdo"], $r["dziendo"], $r["rokdo"]);
		
	if($dzisiaj>=$bod&&$dzisiaj<=$bdo)
{
	$s = $polaczenie->query("SELECT * FROM klienci WHERE id_klienta=$r[id_klienta]");

	while ($p = $s->fetch_assoc())
	{
	         echo'<div class="row justify-content-center mt-5 mb-5 text form-check col-12"> <span class="span1Input"> Imię: '.$p["Imie"].' </span> <span class="span1Input"> Nazwisko: '.$p["Nazwisko"].' </span><span class="span1Input"> Numer rezerwacji: '.$r["id_rezerwacji"]. '</span>
                    </div>';


	}}
else
{


}

}
$z->free();
$polaczenie->close();	
}

?>

            </div>
        </div>
        <div class="divButtonWybierzWersje">
            <a href="witajPracownik.php">
                <button class="btn btn-success batonWybierzWersje" type="button">Strona główna</button>
            </a>
        </div>
    </div>

</body>

</html>