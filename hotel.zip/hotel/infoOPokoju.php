<?php
session_start();
if((isset($_SESSION['start']))&&($_SESSION['start']==true))
{
	$_SESSION['numer']=$_POST['pokoj'];
require_once "connect.php";

$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);

if ($polaczenie->connect_errno!=0)
{
	echo "Error: ".$polaczenie->connect_errno;
}
else
{
 $z = $polaczenie->query("SELECT * FROM pokoje WHERE nr_pokoju='$_SESSION[numer]'");



$r = $z->fetch_assoc();

$_SESSION['koszt']=$r['cena']*$_SESSION['dlugosc'];


}
 }
?>
<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.2/css/bulma.css"> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="font-awesome-4_7_0/css/font-awesome.min.css">

    <link rel="stylesheet" href="style.css">

    <title>InOP</title>
</head>

<body>

    <div class="containerFluidIndex">
        <div class="border border-success rounded pt-5 pb-5">

            <h1 class="text-center">Informacje o pokoju</h1>

            <div class="is-center"><img class="img-fluid rounded mx-auto d-block" src="img/pokoj01.jpg" alt="zdjęcie pokoju"></div>


            <table class="table is-narrow is-striped text-left">
                <thead>
                    <tr>
                        <th>Parametr</th>
                        <th>Ilosc/czy posiada</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Ilosc łóżek</td>
                        <td><?php echo $r['ile_lozek'];  ?></td>
                    </tr>
                    <tr>
                        <td>Klimatyzacja</td>
                        <td><?php echo $r['klimatyzacja'];  ?></td>
                    </tr>
                    <tr>
                        <td>Pokój dla niepalących</td>
                        <td><?php echo $r['niepalacy'];  ?></td>
                    </tr>
                </tbody>
            </table>
        </div>


        <div class="divButtonWybierzWersje text-center">
            <a href="dostepnePokoje.php">
                <button class="btn btn-success batonWybierzWersje" type="button">Cofnij</button>
            </a>
            <a href="wprowadzDaneOsobowe.php">
                <button class="btn btn-success batonWybierzWersje" type="button">Wybierz pokój</button>
            </a>
        </div>
    </div>




</body>

</html>