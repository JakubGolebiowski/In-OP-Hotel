<?php
session_start();

if((isset($_SESSION['start']))&&($_SESSION['start']==true))
{



$od=mktime(0,0,0,$_SESSION['mod'], $_SESSION['dod'], $_SESSION['rod']);
$do=mktime(0,0,0,$_SESSION['mdo'], $_SESSION['ddo'], $_SESSION['rdo']);
}
?>


<!DOCTYPE html>
<html lang="pl">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.2/css/bulma.css"> -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="font-awesome-4_7_0/css/font-awesome.min.css">

  <link rel="stylesheet" href="style.css">
  <title>InOP</title>
</head>

<body>
  <div class="text-center containerFluidIndex">
    <div class="border border-success rounded pt-5 pb-5">
      <div class="row justify-content-center">
        <div class="col-4">
          <h1>Dostępne Parkingi</h1>
        </div>
      </div>
	  
	  <?php
require_once "connect.php";

$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);

if ($polaczenie->connect_errno!=0)
{
	echo "Error: ".$polaczenie->connect_errno;
}
else
{
	
$z = $polaczenie->query("SELECT * FROM miejsca");

$nr=0;
while ($r = $z->fetch_assoc()) {
$flaga=0;
	
	$x = $polaczenie->query("SELECT * FROM rezerwacje WHERE nr_miejsca = '$r[nr_miej]'");
	while($a= $x->fetch_assoc()){
		$bod=mktime(0,0,0, $a["miesod"], $a["dzienod"], $a["rokod"]);
		$bdo=mktime(0,0,0, $a["miesdo"], $a["dziendo"], $a["rokdo"]);
	if(($od<=$bod&&$od<=$bdo&&$do>=$bod&&$do<=$bdo)||($od>=$bod&&$od<=$bdo&&$do>=$bod&&$do<=$bdo)||($od>=$bod&&$od<=$bdo&&$do>=$bod&&$do>=$bdo)||($od<=$bod&&$od<=$bdo&&$do>=$bod&&$do>=$bdo)||($od==$bod&&$do==$bdo)||($od!=$bod&&$do==$bdo)||($od==$bod&&$do!=$bdo))
	{$flaga=1;}
	else
	{
		

	
	
	}
}
if($flaga==0)
{	
if($r["inw"]==1)
{$odp="dla inwalidów";}
else
{$odp="normalne";}



	echo '
	<form action="rezerwacjaParkingu.php" method="POST">
                       <div class="row justify-content-center mt-5 mb-5 text form-check">
        <div class="form-check">
          <label class="form-check-label">
            <input type="radio" class="form-check-input" name="miejsce" id ="miejsce" value="'.$r["nr_miej"].'"><span class="span1Input"> numer miejsca: '.$r["nr_miej"].'</span> <span
              class="span1Input">'.$odp.'</span>
          </label>
        </div>
      </div>
                ';}


}
$z->free();
$polaczenie->close();	
}
?>
	  
	  
	  





    </div>

    <div class="divButtonWybierzWersje text-center">
        <input class="btn btn-success batonWybierzWersje" type="submit" value="Zarezerwuj miejsce">
    </div>
	</form>
  </div>

</body>

</html>