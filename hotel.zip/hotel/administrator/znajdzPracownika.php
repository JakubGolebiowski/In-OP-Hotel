<?php
session_start();

if((isset($_SESSION['zalogowanyA']))&&($_SESSION['zalogowanyA']==true))
{

}
else{			
	header('Location:logowanieAdministratora.php');
}
?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.2/css/bulma.css"> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="font-awesome-4_7_0/css/font-awesome.min.css">

    <link rel="stylesheet" href="../style.css">
    <title>InOP</title>
</head>

<body>
    <div class="text-center containerFluidIndex">
        <div class="border border-success rounded pt-5 pb-5">
            <div class="row justify-content-center">
            <div class="col-sm-12 col-md-12 col-lg-10 col-xl-10 mt-5 mb-5">
                <a href="wylogowywanie.html">
                    <button class="btn btn-success batonWybierzWersje float-right">Wyloguj się</button>
                </a>
            </div>

            <div class="col-8">
                <h1><b>Wyszukaj pracownika</b></h1>
            </div>
            <div class="col-6">
                <h1>Wprowadź imię, nazwisko i nr. identyfikatora w celu wyszukiwania</h1>
            </div>
        </div>
    
        <div class="row justify-content-center mt-5 mb-5 text form-check">


            <form action="pracownikaZnaleziono.php" method="POST">
                <div class="daneOsoboweWprowadz">
                    <label class="label">Imię</label><br>
                    <input id="imie" name="imie" type="text" class="input"
                        placeholder="Imię">
                </div> 
				<div class="daneOsoboweWprowadz">
                    <label class="label">Nazwisko</label><br>
                    <input id="nazwisko" name="nazwisko" type="text" class="input"
                        placeholder="Imię">
                </div>

                <div class="daneOsoboweWprowadz">
                    <label class="label">Nr. identyfikatora</label><br>
                    <input id="nrID" name="nrID" type="text" class="input" placeholder="Nr. identyfikatora">
                </div>
				        <div class="divButtonWybierzWersje text-center">
                <input class="bg-success batonWybierzWersje" type="submit" value="Szukaj" />
        </div>
            </form>
        </div>
    </div>

    </div>
    </div>




</body>

</html>