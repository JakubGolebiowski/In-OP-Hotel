<?php
session_start();

if((isset($_SESSION['start']))&&($_SESSION['start']==true))
{
session_unset();
}

$_SESSION['start']=true;

?>


<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.2/css/bulma.css"> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="font-awesome-4_7_0/css/font-awesome.min.css">

    <link rel="stylesheet" href="style.css">
    <title>InOP</title>
</head>

<body>
    <div class="text-center containerFluidIndex">
        <div class="border border-success rounded pt-5 pb-5">
            <div class="row justify-content-center">
                <div class="col-4">
                    <h1>Wybierz wielkość pokoju</h1>
                </div>
            </div>
            <div class="row justify-content-center mt-5 text">
                <div class="col-4">
                    <form action="dostepnePokoje.php" method="POST">
                        <div class="columns is-mobile is-centered">
                            <div class="field">
                                <div class="control">
                                    <div>
                                        <select class="border border-success rounded" name="ileosob" id="ileosob">
                                          <option value="1" >1-osobowy</option>
                                          <option value="2">2-osobowy</option>
                                          <option value="3">3-osobowy</option>
                                          <option value="4">4-osobowy</option>
                                       </select>
                                    </div>
                                </div>
                            </div>
                        </div>
					
					
        <!-- <div class="row justify-content-center"> -->
            <!-- <div class="col-4"> -->
                <!-- <h1>Data rezerwacji</h1> -->
            <!-- </div> -->
        <!-- </div> -->

        <div class="row justify-content-center mt-5 mb-5 text form-check">


              <div class="daneOsoboweWprowadz">
                  <label class="label">Od</label>
              </div>
              <div class="columns is-mobile is-centered">
                  <div class="daneOsoboweWprowadz ">
						<div class="field " >
                            <div class="control">
                              <div class="select is-primary is-large">
                                <select name="dzienod" id="dzienod">
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                  <option value="3">3</option>
                                  <option value="4">4</option>
                                  <option value="5">5</option>
                                  <option value="6">6</option>
                                  <option value="7">7</option>
                                  <option value="8">8</option>
                                  <option value="9">9</option>
                                  <option value="10">10</option>
                                  <option value="11">11</option>
                                  <option value="12">12</option>
                                  <option value="13">13</option>
                                  <option value="14">14</option>
                                  <option value="15">15</option>
                                  <option value="16">16</option>
                                  <option value="17">17</option>
                                  <option value="18">18</option>
                                  <option value="19">19</option>
                                  <option value="20">20</option>
                                  <option value="21">21</option>
                                  <option value="22">22</option>
                                  <option value="23">23</option>
                                  <option value="24">24</option>
                                  <option value="25">25</option>
                                  <option value="26">26</option>
                                  <option value="27">27</option>
                                  <option value="28">28</option>
                                  <option value="29">29</option>
                                  <option value="30">30</option>
                                  <option value="31">31</option>
                                </select>
                              <!-- </div> -->
                            <!-- </div> -->
                          <!-- </div> -->
                          <!-- <div class="field " > -->
                            <!-- <div class="control"> -->
                              <!-- <div class="select is-primary is-large"> -->
                                <select name="miesiacod" id="miesiacod">
                                  <option value="1">January</option>
                                  <option value="2">Febuary</option>
                                  <option value="3">March</option>
                                  <option value="4">April</option>
                                  <option value="5">May</option>
                                  <option value="6">June</option>
                                  <option value="7">July</option>
                                  <option value="8">August</option>
                                  <option value="9">September</option>
                                  <option value="10">October</option>
                                  <option value="11">November</option>
                                  <option value="12">December</option>
                                </select>
                              <!-- </div> -->
                            <!-- </div> -->
                          <!-- </div> -->
                          <!-- <div class="field " > -->
                            <!-- <div class="control"> -->
                              <!-- <div class="select is-primary is-large"> -->
                                <select name="rokod" id="rokod">
                                  <option value="2020">2020</option>
                                  <option value="2021">2021</option>
                                  <option value="2022">2022</option>
                                  <option value="2023">2023</option>
                                </select>
                              </div>
                            </div>
                          </div>
                  </div>
              </div>
              <div class="daneOsoboweWprowadz">
                <label class="label">Do</label>
            </div>
            <div class="columns is-mobile is-centered">
                <div class="daneOsoboweWprowadz ">
				
							 
						  
						  
                          <div class="field " >
                            <div class="control">
                              <div class="select is-primary is-large">
                                <select name="dziendo" id="dziendo">
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                  <option value="3">3</option>
                                  <option value="4">4</option>
                                  <option value="5">5</option>
                                  <option value="6">6</option>
                                  <option value="7">7</option>
                                  <option value="8">8</option>
                                  <option value="9">9</option>
                                  <option value="10">10</option>
                                  <option value="11">11</option>
                                  <option value="12">12</option>
                                  <option value="13">13</option>
                                  <option value="14">14</option>
                                  <option value="15">15</option>
                                  <option value="16">16</option>
                                  <option value="17">17</option>
                                  <option value="18">18</option>
                                  <option value="19">19</option>
                                  <option value="20">20</option>
                                  <option value="21">21</option>
                                  <option value="22">22</option>
                                  <option value="23">23</option>
                                  <option value="24">24</option>
                                  <option value="25">25</option>
                                  <option value="26">26</option>
                                  <option value="27">27</option>
                                  <option value="28">28</option>
                                  <option value="29">29</option>
                                  <option value="30">30</option>
                                  <option value="31">31</option>
                                </select>
                              <!-- </div> -->
                            <!-- </div> -->
                          <!-- </div> -->
                          <!-- <div class="field " > -->
                            <!-- <div class="control"> -->
                              <!-- <div class="select is-primary is-large"> -->
                                <select name="miesiacdo" id="miesiacdo">
                                  <option value="1">January</option>
                                  <option value="2">Febuary</option>
                                  <option value="3">March</option>
                                  <option value="4">April</option>
                                  <option value="5">May</option>
                                  <option value="6">June</option>
                                  <option value="7">July</option>
                                  <option value="8">August</option>
                                  <option value="9">September</option>
                                  <option value="10">October</option>
                                  <option value="11">November</option>
                                  <option value="12">December</option>
                                </select>
                              <!-- </div> -->
                            <!-- </div> -->
                          <!-- </div> -->
                          <!-- <div class="field " > -->
                            <!-- <div class="control"> -->
                              <!-- <div class="select is-primary is-large"> -->
                                <select name="rokdo" id="rokdo">
                                  <option value="2020">2020</option>
                                  <option value="2021">2021</option>
                                  <option value="2022">2022</option>
                                  <option value="2023">2023</option>
                                </select>
                              </div>
                            </div>
                          </div>
						  
						  
						  
						  
						  
                </div>
            </div>
			      </div>

                </div>
            </div>
            <br><br><br>
        </div>


  
			        <div class="divButtonWybierzWersje text-center">
                <input type="submit" class="btn btn-success batonWybierzWersje" value="Przejdź dalej">
        </div>
          </form>
	  
					
					
					  </div>
					
					





</body>

</html>