# In-OP-Hotel
InżOP-Hotel blablabla
# Aplikacja zaczyna się od pliku startPage.html
<h4>To wersja bardzo wstępna, dużo rzeczy poprawię.</h4>
