<?php
session_start();

if((isset($_SESSION['start']))&&($_SESSION['start']==true))
{
	if((isset($_POST['imie']))&&(isset($_POST['nazwisko']))&&(isset($_POST['mail']))&&(isset($_POST['data']))&&(isset($_POST['platnosc'])))
	{
$_SESSION['imie']=$_POST['imie'];
$_SESSION['nazwisko']=$_POST['nazwisko'];
$_SESSION['mail']=$_POST['mail'];
$_SESSION['data']=$_POST['data'];
$platnosc=$_POST['platnosc'];

if($platnosc == "gotowka")
{
	$_SESSION['gotowka']='tak';
	$_SESSION['przelew']='nie';
}
else{
if($platnosc =="przelew")
{
	$_SESSION['gotowka']='nie';
	$_SESSION['przelew']='tak';
}}



require_once "connect.php";
	
	
	try 
	{
		$polaczenie = new mysqli($host, $db_user, $db_password, $db_name);
		
		if ($polaczenie->connect_errno!=0)
		{
			throw new Exception(mysqli_connect_errno()); 
		}
		else
		{
			$test=$polaczenie->query("SELECT id_klienta FROM klienci WHERE Imie='$_SESSION[imie]' AND Nazwisko='$_SESSION[nazwisko]' AND data_urodzenia='$_SESSION[data]' AND mail='$_SESSION[mail]'");
			$testtest=$test->num_rows;
			if($testtest>0)
			{
				echo "";
			}
		else
		{
			$z=$polaczenie->query("INSERT INTO klienci VALUES (NULL, '$_SESSION[imie]', '$_SESSION[nazwisko]', '$_SESSION[data]', '$_SESSION[mail]' )");
		}
			$zz=$polaczenie->query("SELECT id_klienta FROM klienci WHERE Imie='$_SESSION[imie]' AND Nazwisko='$_SESSION[nazwisko]' AND data_urodzenia='$_SESSION[data]' AND mail='$_SESSION[mail]'");
			
			$zzz=$zz->fetch_assoc();
			$nr_klienta=$zzz['id_klienta'];
			
			$r=$polaczenie->query("INSERT INTO rezerwacje VALUES (NULL, '$_SESSION[numer]', '$nr_klienta', '$_SESSION[dod]', '$_SESSION[mod]', '$_SESSION[rod]', '$_SESSION[ddo]', '$_SESSION[mdo]', '$_SESSION[rdo]', '$_SESSION[przelew]', '$_SESSION[gotowka]', '$_SESSION[koszt]', '0' )");
			
			
			$rr=$polaczenie->query("SELECT id_rezerwacji FROM rezerwacje WHERE nr_pokoju='$_SESSION[numer]' AND id_klienta='$nr_klienta' AND dzienod='$_SESSION[dod]' AND miesod='$_SESSION[mod]'AND rokod='$_SESSION[rod]' AND dziendo='$_SESSION[ddo]' AND miesdo='$_SESSION[mdo]' AND rokdo='$_SESSION[rdo]' AND przelew='$_SESSION[przelew]' AND zaplata_na_miejscu='$_SESSION[gotowka]' AND kwota='$_SESSION[koszt]' ");

			$rrr=$rr->fetch_assoc();
			$_SESSION['nr_rezerwacji']=$rrr['id_rezerwacji'];
			
			$polaczenie->close();
		}	
		
	}
	catch (Exception $e)
	{
		echo 'Błąd serwera'.$e;
	}
	}

else
{
	header("Location:wprowadzDaneOsobowe.php");
	$_SESSION['brak']=true;
}}
?>

<!DOCTYPE html>
<html lang="pl">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.2/css/bulma.css"> -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="font-awesome-4_7_0/css/font-awesome.min.css">

  <link rel="stylesheet" href="style.css">
  <title>InOP</title>
</head>

<body>
  <div class="text-center containerFluidIndex">

    <div class="border border-success rounded pt-5 pb-5">

      <div class="row justify-content-center">
        <div class="col-10">
          <h1 class="title" ><b>Dane rezerwacji zostały zapisane</b></h1>
<?php
		if($_SESSION['przelew']=='tak'&&$_SESSION['gotowka']=='nie'){
			
         echo '<h1 class="title" ><b>Oto numer konta potrzebny do przelewu:</br>
		12 3642 6534 0000 4321 9854 5421</b></h1>';}
		  ?>
          <h1 class="title" ><b>Oto numer Twojej rezerwacji: <?php echo $_SESSION['nr_rezerwacji']; ?></b></h1>
          <h1 class="title" ><b>Numer ten został dodany do bazy danych</b></h1>
        </div>
      </div>
<br>
    </div>

    <div class="row divButtonWybierzWersje text-center">
      <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-5 mb-6">
      <a href="oNasRegulamin.html">
        <button class="btn btn-success batonWybierzWersje">Wróć na stronę główną</button>
      </a>
    </div>
    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-4  mb-6">
      <a href="dostepneParkingi.php">
        <button class="btn btn-success batonWybierzWersje" type="button">Rezerwuj <br> miejsce parkingowe</button>
      </a>
    </div>
    
    <div class="col-sm-11 col-md-11 col-lg-12 col-xl-12 mt-5 mb-5">
      <a href="wyswietlDaneRezerwacji.php">
        <button class="btn btn-success batonWybierzWersje" type="button">Wyświetl dane rezerwacji</button>
      </a>
    </div>
  </div>
  </div>
  
</body>

</html>